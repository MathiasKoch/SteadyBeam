#include <stdio.h>

int main(int argc, char **argv)
{
	printf("Hello OpenWrt\n");

	return 0;
}
